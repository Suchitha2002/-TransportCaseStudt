﻿using Microsoft.AspNetCore.Mvc;
using TransportApplication.Entity;
using TransportApplication.Repository;

namespace TransportApplication.Controllers
{
    [ApiController]
    [Route("api/[Controller]")]
    public class TransportListController : Controller

    {
        private readonly ITransportListRepository _transportListRepository;

        public TransportListController(ITransportListRepository transportListRepository)
        {
            _transportListRepository = transportListRepository;
        }

        [HttpGet,Route("{userId}")]
        public async Task<ActionResult<IEnumerable<TransportList>>> GetTransportLists(Guid userId)
        {
            var transportLists = await _transportListRepository.GetAllTransportListAsync(userId);
            return Ok(transportLists);
        }
        [HttpGet,Route("details/{id}")]
        public async Task<ActionResult<TransportList>> GetTransportList(Guid id)
        {
            var transportList = await _transportListRepository.GetTransportListByIdAsync(id);
            if (transportList == null)
            {
                return NotFound();
            }
            return Ok(transportList);
        }
        [HttpPost("AddTransportList")]
        public async Task<ActionResult> AddTransportList([FromBody] TransportList transportList)
        {
            transportList.TransportListId = Guid.NewGuid();
            transportList.DateCreated = DateTime.UtcNow;

            await _transportListRepository.AddTransportListAsync(transportList);
            return CreatedAtAction(nameof(GetTransportList), new { id = transportList.TransportListId }, transportList);
        }
        [HttpPut("UpdateTransportList/{id}")]
        public async Task<IActionResult> UpdateTransportList(Guid id, [FromBody] TransportList transportList)
        {
            if (id != transportList.TransportListId)
            {
                return BadRequest();
            }

            await _transportListRepository.UpdateTransportListAsync(transportList);
            return NoContent();
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTransportList(Guid id)
        {
            var transportList = await _transportListRepository.GetTransportListByIdAsync(id);
            if(transportList==null)
            {
                return NotFound();
            }
            await _transportListRepository.DeleteTransportListAsync(transportList.TransportListId);
            return NoContent();
        }


    }
}

