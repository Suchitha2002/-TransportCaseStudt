﻿using Microsoft.AspNetCore.Mvc;
using TransportApplication.Entity;
using TransportApplication.Repository;

namespace TransportApplication.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class Statisticsontrollers : Controller
    {
        private readonly IStatisticsRepository _statisticsRepository;

        public Statisticsontrollers(IStatisticsRepository statisticsRepository)
        {
            _statisticsRepository = statisticsRepository;
        }

        [HttpGet("{userId}")]
        public async Task<ActionResult<Statistics>> GetStatistics(Guid userId)
        {
            var statistics = await _statisticsRepository.GetStatisticsByUserIdAsync(userId);
            if (statistics == null)
            {
                return NotFound();
            }
            return Ok(statistics);
        }
        [HttpPut,Route("Update/{userId}")]
        public async Task<IActionResult> UpdateStatistics(Guid userId, [FromBody] Statistics statistics)
        {
            if (userId != statistics.UserId)
            {
                return BadRequest();
            }

            statistics.LastUpdate = DateTime.UtcNow;
            await _statisticsRepository.UpdateStatisticsAsync(statistics);
            return NoContent();
        }

    }
}
