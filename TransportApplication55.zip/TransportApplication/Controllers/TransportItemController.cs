﻿using Microsoft.AspNetCore.Mvc;
using TransportApplication.Entity;
using TransportApplication.Repository;

namespace TransportApplication.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TransportItemController : Controller
    {
        private readonly ITransportItemRepository _transportItemRepository;

        public TransportItemController(ITransportItemRepository transportItemRepository)
        {
            _transportItemRepository = transportItemRepository;
        }
        // GET: api/TransportItem/{transportListId}

        [HttpGet("{transportListId}")] 
        public  async Task<ActionResult<IEnumerable<TransportItem>>> GetTransportItems(Guid userId)
        {
            var transportItems = await _transportItemRepository.GetTransportItemsByListIdAsync(userId);
            return Ok(transportItems);
        }

        // GET: api/TransportItem/details/{id}
        [HttpGet("Details/{id}")]
        public async Task<ActionResult<TransportItem>> GetTransportItem(Guid id)
        {
            var transportItem = await _transportItemRepository.GetTransportItemByIdAsync(id);
            if (transportItem == null)
            {
                return NotFound();
            }
            return Ok(transportItem);

        }
        // POST: api/TransportItem

        [HttpPost("ADD")]
        public async Task<ActionResult> AddTransportItem([FromBody] TransportItem transportItem)
        {
            if (transportItem == null)
            {
                return BadRequest();
            }
            transportItem.TransportItemId= Guid.NewGuid();
            await _transportItemRepository.AddTransportItemAsync(transportItem);
            return CreatedAtAction(nameof(GetTransportItem),new {id=transportItem.TransportItemId},transportItem);
        }
        // PUT: api/TransportItem/{id}

        [HttpPut("Update/{id}")]

        public async Task<IActionResult> UpdateTransportItem(Guid id, [FromBody] TransportItem transportItem)
        {
            if (id != transportItem.TransportItemId)
            {
                return BadRequest();
            }

            await _transportItemRepository.UpdateTransportItemAsync(transportItem);
            return NoContent();
        }
        // DELETE: api/TransportItem/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTransportItem(Guid id)
        {
            var transportItem = await _transportItemRepository.GetTransportItemByIdAsync(id);
            if (transportItem == null)
            {
                return NotFound();
            }
            await _transportItemRepository.DeleteTransportItemAsync(id);
            return NoContent();
        }
    }
}
