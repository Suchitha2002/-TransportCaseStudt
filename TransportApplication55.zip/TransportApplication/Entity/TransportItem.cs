﻿namespace TransportApplication.Entity
{
    public class TransportItem
    {
        public Guid TransportItemId { get; set; }
        public string ItemName { get; set; }
        public Guid TransportListId { get; set; } // Foreign key property
        public TransportList TransportList { get; set; }
    }
}
