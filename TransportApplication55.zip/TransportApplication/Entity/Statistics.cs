﻿namespace TransportApplication.Entity
{
    public class Statistics
    {
        public Guid StatisticsId { get; set; }
        public Guid UserId { get; set; } //Foreign Key
        public int TotalItems { get; set; } 
        public double AverageDistance { get; set; }
        public DateTime LastUpdate { get; set; }

        //Navigation Properties
        public User User { get; set; }

        
    }
}
