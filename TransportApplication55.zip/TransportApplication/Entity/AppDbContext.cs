﻿using Microsoft.EntityFrameworkCore;

namespace TransportApplication.Entity
{
    public class AppDbContext:DbContext
    {
        private IConfiguration _configuration;
      

        public AppDbContext(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        //Entity Sets

        public DbSet<User> Users { get; set; }

        public DbSet<Item> Items { get; set; }

        public DbSet<TransportItem> TransportItems { get; set; }

        public DbSet<TransportList> TransportLists { get; set; }

        public DbSet<Statistics> Statistics { get; set; }

        // Ensures the Email property is unique
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<User>()
                .HasIndex(u => u.Email)
                .IsUnique();
            modelBuilder.Entity<Item>()
                .Property(i => i.Price)
                .HasColumnType("decimal(18,2");

            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<TransportList>()
                .HasMany(t => t.TransportItems)
                .WithOne(ti => ti.TransportList)
                .HasForeignKey(ti => ti.TransportListId)
                .OnDelete(DeleteBehavior.Cascade);

           modelBuilder.Entity<Statistics>()
                .HasOne(s=>s.User)
                .WithMany(u=>u.Statistics)
                .HasForeignKey(s => s.UserId)
                .OnDelete(DeleteBehavior.Cascade);

        }



        //Configure ConnectionString

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_configuration.GetConnectionString("TransportConnection"));
        }
    }
}
