﻿namespace TransportApplication.Entity
{
    public class TransportList
    {
        public Guid TransportListId { get; set; }
        public string ListName { get; set; } //cannot be nullvalue
        public DateTime DateCreated { get; set; }
        public Guid UserId { get; set; }
        public User User { get; set; }
        public ICollection<TransportItem> TransportItems { get; set; }
    }
}
