﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TransportApplication.Migrations
{
    /// <inheritdoc />
    public partial class CreateStatisticsDB : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TransportItems_Items_transportItemItemId",
                table: "TransportItems");

            migrationBuilder.DropForeignKey(
                name: "FK_TransportItems_TransportLists_TransportListId",
                table: "TransportItems");

            migrationBuilder.DropIndex(
                name: "IX_TransportItems_transportItemItemId",
                table: "TransportItems");

            migrationBuilder.DropColumn(
                name: "DateUpdated",
                table: "TransportLists");

            migrationBuilder.DropColumn(
                name: "ItemId",
                table: "TransportItems");

            migrationBuilder.DropColumn(
                name: "TransportDate",
                table: "TransportItems");

            migrationBuilder.DropColumn(
                name: "UserId",
                table: "TransportItems");

            migrationBuilder.DropColumn(
                name: "transportItemItemId",
                table: "TransportItems");

            migrationBuilder.RenameColumn(
                name: "Destination",
                table: "TransportItems",
                newName: "ItemName");

            migrationBuilder.AlterColumn<Guid>(
                name: "TransportListId",
                table: "TransportItems",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"),
                oldClrType: typeof(Guid),
                oldType: "uniqueidentifier",
                oldNullable: true);

            migrationBuilder.CreateTable(
                name: "Statistics",
                columns: table => new
                {
                    StatisticsId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    UserId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    TotalItems = table.Column<int>(type: "int", nullable: false),
                    AverageDistance = table.Column<double>(type: "float", nullable: false),
                    LastUpdate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UserId1 = table.Column<string>(type: "varchar(10)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Statistics", x => x.StatisticsId);
                    table.ForeignKey(
                        name: "FK_Statistics_Users_UserId1",
                        column: x => x.UserId1,
                        principalTable: "Users",
                        principalColumn: "UserId");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Statistics_UserId1",
                table: "Statistics",
                column: "UserId1");

            migrationBuilder.AddForeignKey(
                name: "FK_TransportItems_TransportLists_TransportListId",
                table: "TransportItems",
                column: "TransportListId",
                principalTable: "TransportLists",
                principalColumn: "TransportListId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TransportItems_TransportLists_TransportListId",
                table: "TransportItems");

            migrationBuilder.DropTable(
                name: "Statistics");

            migrationBuilder.RenameColumn(
                name: "ItemName",
                table: "TransportItems",
                newName: "Destination");

            migrationBuilder.AddColumn<DateTime>(
                name: "DateUpdated",
                table: "TransportLists",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AlterColumn<Guid>(
                name: "TransportListId",
                table: "TransportItems",
                type: "uniqueidentifier",
                nullable: true,
                oldClrType: typeof(Guid),
                oldType: "uniqueidentifier");

            migrationBuilder.AddColumn<Guid>(
                name: "ItemId",
                table: "TransportItems",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<DateTime>(
                name: "TransportDate",
                table: "TransportItems",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<Guid>(
                name: "UserId",
                table: "TransportItems",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "transportItemItemId",
                table: "TransportItems",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.CreateIndex(
                name: "IX_TransportItems_transportItemItemId",
                table: "TransportItems",
                column: "transportItemItemId");

            migrationBuilder.AddForeignKey(
                name: "FK_TransportItems_Items_transportItemItemId",
                table: "TransportItems",
                column: "transportItemItemId",
                principalTable: "Items",
                principalColumn: "ItemId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_TransportItems_TransportLists_TransportListId",
                table: "TransportItems",
                column: "TransportListId",
                principalTable: "TransportLists",
                principalColumn: "TransportListId");
        }
    }
}
