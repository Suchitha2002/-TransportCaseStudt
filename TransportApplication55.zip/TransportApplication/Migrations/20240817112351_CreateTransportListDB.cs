﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TransportApplication.Migrations
{
    /// <inheritdoc />
    public partial class CreateTransportListDB : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "TransportListId",
                table: "TransportItems",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "TransportLists",
                columns: table => new
                {
                    TransportListId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    UserId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ListName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DateUpdated = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UserId1 = table.Column<string>(type: "varchar(10)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TransportLists", x => x.TransportListId);
                    table.ForeignKey(
                        name: "FK_TransportLists_Users_UserId1",
                        column: x => x.UserId1,
                        principalTable: "Users",
                        principalColumn: "UserId");
                });

            migrationBuilder.CreateIndex(
                name: "IX_TransportItems_TransportListId",
                table: "TransportItems",
                column: "TransportListId");

            migrationBuilder.CreateIndex(
                name: "IX_TransportLists_UserId1",
                table: "TransportLists",
                column: "UserId1");

            migrationBuilder.AddForeignKey(
                name: "FK_TransportItems_TransportLists_TransportListId",
                table: "TransportItems",
                column: "TransportListId",
                principalTable: "TransportLists",
                principalColumn: "TransportListId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TransportItems_TransportLists_TransportListId",
                table: "TransportItems");

            migrationBuilder.DropTable(
                name: "TransportLists");

            migrationBuilder.DropIndex(
                name: "IX_TransportItems_TransportListId",
                table: "TransportItems");

            migrationBuilder.DropColumn(
                name: "TransportListId",
                table: "TransportItems");
        }
    }
}
