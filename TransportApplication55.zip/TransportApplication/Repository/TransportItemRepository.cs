﻿using Microsoft.EntityFrameworkCore;
using TransportApplication.Entity;

namespace TransportApplication.Repository
{
    public class TransportItemRepository : ITransportItemRepository

    {
        private readonly AppDbContext _context;

        public TransportItemRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<TransportItem>> GetTransportItemsByListIdAsync(Guid transportListId)
        {
            return await _context.TransportItems
                                 .Where(ti => ti.TransportListId == transportListId)
                                 .ToListAsync();
        }

        public async Task<TransportItem> GetTransportItemByIdAsync(Guid id)
        {
            return await _context.TransportItems
                                 .FirstOrDefaultAsync(ti => ti.TransportItemId == id);
        }

        public async Task AddTransportItemAsync(TransportItem transportItem)
        {
            await _context.TransportItems.AddAsync(transportItem);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateTransportItemAsync(TransportItem transportItem)
        {
            _context.TransportItems.Update(transportItem);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteTransportItemAsync(Guid id)
        {
            var transportItem = await _context.TransportItems.FindAsync(id);
            if (transportItem != null)
            {
                _context.TransportItems.Remove(transportItem);
                await _context.SaveChangesAsync();
            }
        }
    }

}


