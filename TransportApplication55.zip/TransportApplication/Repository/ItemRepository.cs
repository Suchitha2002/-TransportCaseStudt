﻿using Microsoft.EntityFrameworkCore;
using TransportApplication.Entity;

namespace TransportApplication.Repository
{
    public class ItemRepository : IItemRepository
    {
        private readonly AppDbContext _context;

        public ItemRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task AddItemAsync(Item item)
        {
            await _context.Items.AddAsync(item);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteItemAsync(Guid itemId)
        {
            var item = await _context.Items.FindAsync(itemId);
            if (item != null)
            {
                _context.Items.Remove(item);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<IEnumerable<Item>> GetAllItemsAsync()
        {
            return await _context.Items.ToListAsync();
        }
        public async Task<Item> GetItemByIdAsync(Guid itemId)
        {
            return await _context.Items.FindAsync(itemId);
        }
        public async Task<IEnumerable<Item>> SearchItemsByNameAsync(string name)
        {
            return await _context.Items
                                 .Where(i => EF.Functions.Like(i.ItemName, $"%{name}%"))
                                 .ToListAsync();
        }
        public async Task UpdateItemAsync(Item item)
        {
            var existingItem = await _context.Items.FindAsync(item.ItemId);
            if (existingItem != null)
            {
                throw new KeyNotFoundException("Item not Found");
            }

            //update the item properties
            _context.Items.Add(item);

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException) 
            {
                await _context.Entry(existingItem).ReloadAsync();

                throw new Exception("The item you attempted to update was modified or deleted by another process");

            }
        }
    }
}
