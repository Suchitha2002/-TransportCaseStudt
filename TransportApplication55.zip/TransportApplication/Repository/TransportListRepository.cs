﻿using TransportApplication.Entity;
using Microsoft.EntityFrameworkCore;


namespace TransportApplication.Repository
{
    public class TransportListRepository : ITransportListRepository
    {
        private readonly AppDbContext _context;

        public TransportListRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task AddTransportListAsync(TransportList transportList)
        {
           await _context.TransportLists.AddAsync(transportList);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteTransportListAsync(Guid transportListId)
        {
            var transportList = await _context.TransportLists.FindAsync(transportListId);
            if (transportList != null)
            {
                _context.TransportLists.Remove(transportList);
                await _context.SaveChangesAsync();
            }
        }

       
        public async Task<IEnumerable<TransportList>> GetAllTransportListAsync(Guid userId)
        {
            return await _context.TransportLists
                                 .Where(t => t.UserId == userId)
                                 .Include(t => t.TransportItems)
                                 .ToListAsync();
        }

        

        public async Task<TransportList> GetTransportListByIdAsync(Guid transportListId)
        {
            var transportList = await _context.TransportLists
                                              .Include(t=>t.TransportItems)
                                              .FirstOrDefaultAsync(t=>t.TransportListId==transportListId);
            return transportList;
        }

        public async Task UpdateTransportListAsync(TransportList transportList)
        {
            _context.TransportLists.Update(transportList);
            await _context.SaveChangesAsync();
        }
    }
}
