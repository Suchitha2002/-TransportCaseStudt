﻿using TransportApplication.Entity;

namespace TransportApplication.Repository
{
    public interface IItemRepository
    {
        Task<IEnumerable<Item>> GetAllItemsAsync();
        Task<Item> GetItemByIdAsync(Guid itemId);
        Task<IEnumerable<Item>> SearchItemsByNameAsync(string name);
        Task AddItemAsync(Item item);
        Task UpdateItemAsync(Item item);
        Task DeleteItemAsync(Guid itemId);
    }
}
