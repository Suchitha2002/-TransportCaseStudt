﻿using TransportApplication.Entity;
using Microsoft.EntityFrameworkCore;

namespace TransportApplication.Repository
{
    public class StatisticsRepository : IStatisticsRepository
    {
        private readonly AppDbContext _context;

        public StatisticsRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<Statistics> GetStatisticsByUserIdAsync(Guid userId)
        {
            return await _context.Statistics
                                 .FirstOrDefaultAsync(s=> s.UserId == userId);
        }

        public async Task UpdateStatisticsAsync(Statistics statistics)
        {
            _context.Statistics.Update(statistics);
            await _context.SaveChangesAsync();
        }
    }
}
