﻿using TransportApplication.Entity;

namespace TransportApplication.Repository
{
    public interface IStatisticsRepository
    {
        Task<Statistics> GetStatisticsByUserIdAsync(Guid userId);
        Task UpdateStatisticsAsync(Statistics statistics);
    }
}
