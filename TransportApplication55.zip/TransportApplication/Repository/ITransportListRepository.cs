﻿using TransportApplication.Entity;

namespace TransportApplication.Repository
{
    public interface ITransportListRepository
    {
        Task AddTransportListAsync(TransportList transportList);
        Task DeleteTransportListAsync(Guid Id);
        Task<IEnumerable<TransportList>> GetAllTransportListAsync(Guid userId);
        Task<TransportList> GetTransportListByIdAsync(Guid transportListId);
        Task UpdateTransportListAsync(TransportList transportList);
    }

}
