﻿using Microsoft.EntityFrameworkCore;

namespace TransportappAPI.Entities
{
    public class TransportAppContextBase : TransportAppContextBaseBase
    {
    }
}