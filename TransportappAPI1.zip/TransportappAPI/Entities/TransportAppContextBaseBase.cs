﻿using Microsoft.EntityFrameworkCore;

namespace TransportappAPI.Entities
{
    public class TransportAppContextBaseBase
    {

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Apply unique constraint on Email
            modelBuilder.Entity<User>()
                .HasIndex(u => u.Email)
                .IsUnique();

            // Additional configurations can be done here
        }
    }
}