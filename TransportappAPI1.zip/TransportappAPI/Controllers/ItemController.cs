﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using TransportappAPI.Entities;
using TransportappAPI.Repository;

namespace TransportappAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ItemController : ControllerBase
    {
        private readonly IItemRepository _itemRepository;

        public ItemController(IItemRepository itemRepository)
        {
            _itemRepository = itemRepository;

        }
        [HttpGet,Route("GetItems")]

        public async Task<ActionResult<IEnumerable<Item>>> GetItems(Ok ok)
        {
            var items=await _itemRepository.GetAllItemAsync();
            return Ok(items);
        }

       
        [HttpGet("{id}")]

        public async Task<ActionResult<Item>> GetItem(int id)
        {
            var item = await _itemRepository.GetItemAsync(id);
            if(item == null)
            {
                return NotFound();
            }
            return Ok(item);
        }

       
        [HttpGet("search")]

        public async Task<ActionResult<IEnumerable<Item>>> SearchItem([FromQuery] string name)
        {
            var item = await _itemRepository.SearchItemByNameAsync(name);
            return Ok(item);

        }
        [HttpPost,Route("AddItem")]
        public async Task<ActionResult> AddItem([FromBody] Item item)
        {
            //item.ItemId = Guid.NewGuid();
            //tem.DateAdded = DateTime.Now;
            await _itemRepository.AddItemAsync(item);
            return Ok(item);

        }
        [HttpPut,Route("UpdateItem/{id}")]
        public async Task<IActionResult> UpdateItem(Guid id, [FromBody] Item item)
        {
           
            await _itemRepository.UpdateItemAsync(item);
            return NoContent();

        }
        [HttpDelete,Route("DeleteItem/{id}")]
        public async Task<IActionResult> DeleteItem(int id)
        {
            await _itemRepository.DeleteItemAsync(id);
            return NoContent();
        }
    }
}