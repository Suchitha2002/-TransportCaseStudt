﻿namespace TransportappAPI.Controllers.Entities
{
    public class User
    {
    }
}
