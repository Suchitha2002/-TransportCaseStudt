﻿using Microsoft.AspNetCore.Mvc;
using TransportappAPI.Entities;
using TransportappAPI.Models;
using TransportappAPI.Repository;

namespace TransportappAPI.Controllers
{
    public class AuthenticateController: Controller
    {
        private readonly IUserRepository _userRepository;

        public AuthenticateController(IUserRepository userRepository)
        {
            _userRepository = userRepository;


        }
        [HttpGet, Route("GetAllUsers")]
        public IActionResult GetAllUsers()
        {
            var users = _userRepository.GetAllUsers();
            return Ok(users);
        }
        [HttpPost, Route("Registraion")]
        public IActionResult Add([FromBody] User user)
        {
            if (ModelState.IsValid)
            {
                _userRepository.Register(user);
                return StatusCode(200, user);
            }
            else return BadRequest("Enter Valid Details");
        }
        [HttpPost, Route("Validate")]
        public IActionResult ValidUser(Login login)
        {

            if (ModelState.IsValid)
            {
                AuthResponse authReponse = null;
                var user = _userRepository.ValidUser(login.Email, login.Password);
                if (user != null)
                {
                    authReponse = new AuthResponse()
                    {
                        UserId = user.UserId,
                        Role = user.Role,
                        UserName = user.Name,
                        Mobile = user.Mobile,

                    };
                }

                return Ok(authReponse);


            }
            else return BadRequest("Enter Valid details");





        }
        [HttpDelete, Route("Delete User")]
        public IActionResult Delete([FromQuery] string id)
        {
            _userRepository.Delete(id);
            return Ok(id);

        }
        [HttpPut, Route("Update User")]
        public IActionResult Update(User user)
        {
            _userRepository.Update(user);
            return StatusCode(200, user);
        }

    }
}
