﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TransportappAPI.Migrations
{
    /// <inheritdoc />
    public partial class CreateTraApp1db : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
