﻿using TransportappAPI.Entities;


namespace TransportappAPI.Repository
{
    public interface IUserRepository
    {
        void Register(User user);
        User ValidUser(string emial, string password);
        List<User> GetAllUsers();
        void Delete(string id);

        void Update(User user);


    }

}
