﻿using TransportappAPI.Entities;

namespace TransportappAPI.Repository
{
    public interface IItemRepository
    {
        Task<IEnumerable<Item>> GetAllItemAsync();

        Task<Item> GetItemAsync(int id);

        Task<IEnumerable<Item>> SearchItemByNameAsync(string name);

        Task AddItemAsync(Item item);

        Task UpdateItemAsync(Item item);
        Task DeleteItemAsync(int id);
        
    }
}
