﻿using Microsoft.EntityFrameworkCore;
using TransportappAPI.Entities;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using TransportappAPI.Entities;

namespace TransportappAPI.Repository
{

    public class UserRepository :  IUserRepository
    {
        private readonly TransportAppConnection _context;

        public UserRepository(TransportAppConnection context)
        {
            _context = context;
        }

        // Constructor with TransportappAPI


        // Constructor with TransportappAPI and IConfiguration
       

        public void Delete(string id)
        {
            var user = _context.Users.Find(id);
            _context.Users.Remove(user);
            _context.SaveChanges();
        }

        public List<User> GetAllUsers()
        {
            return _context.Users.ToList();
        }



        public void Register(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
        }

        public void Update(User user)
        {
            _context.Users.Update(user);
            _context.SaveChanges();
        }
        public User ValidUser(string email, string password)
        {
            try
            {
                {
                    var user = _context.Users.FirstOrDefault(u => u.Email == email & u.Password == password);
                    if (user != null)
                    {
                        return user;
                    }
                    else
                        Console.WriteLine("User validation failed.");
                    return null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("an Error Ocucured" + ex.Message);
                return null;

            }


        }
    }
}

