﻿using Microsoft.EntityFrameworkCore;
using TransportappAPI.Entities;

namespace TransportappAPI.Repository
{
    public class ItemRepository : IItemRepository
    {
        private readonly TransportAppConnection _context;

        public ItemRepository(TransportAppConnection context)
        {
            _context = context;
        }

        public async Task AddItemAsync(Item item)
        {
            await _context.Items.AddAsync(item);
            await _context.SaveChangesAsync();//
        }
        public async Task<IEnumerable<Item>> GetAllItemAsync()
        {
            return await _context.Items.ToListAsync();
        }

        public async Task<Item> GetItemAsync(int id)
        {
            return await _context.Items.FindAsync(id);
        }

       public async Task<IEnumerable<Item>> SearchItemByNameAsync(string name)
        {
           return await _context.Items.Where(i => EF.Functions.Like(i.ItemName,$"%{name}")).ToListAsync();   
        }

        public async Task UpdateItemAsync(Item item)
        {
            _context.Items.Update(item);
            await _context.SaveChangesAsync();
        }
        public async Task DeleteItemAsync(int id)
        {
            var item = await _context.Items.FindAsync(id);
            if (item != null) 
            {
                _context.Items.Remove(item);
                await _context.SaveChangesAsync();
            }
        }
    }
}
