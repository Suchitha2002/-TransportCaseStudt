﻿using Microsoft.AspNetCore.Mvc;
using TransportApplication.Entity;
using TransportApplication.Repository;

namespace TransportApplication.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ItemController : Controller
    {
        private readonly IItemRepository _itemRepository;
        public ItemController(IItemRepository itemRepository)
        {
            _itemRepository = itemRepository;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Item>>> GetItems()
        {
            var items = await _itemRepository.GetAllItemsAsync();
            return Ok(items);
        }

        [HttpGet,Route("GetItem/{id}")]
        public async Task<ActionResult<Item>> GetItem(Guid id)
        {
            var item = await _itemRepository.GetItemByIdAsync(id);
            if (item == null)
            {
                return NotFound();
            }
            return Ok(item);
        }
        [HttpPost,Route("AddItem/{id}")]
        public async Task<ActionResult> AddItem([FromBody] Item item)
        {
            item.ItemId = Guid.NewGuid();
            item.DateAdded = DateTime.UtcNow;
            await _itemRepository.AddItemAsync(item);
            return CreatedAtAction(nameof(GetItem), new { id = item.ItemId }, item);
        }
        [HttpPut,Route("UpdateItem/{id}")]
        public async Task<IActionResult> UpdateItem(Guid id, [FromBody] Item item)
        {
            if (id != item.ItemId)
            {
                return BadRequest();
            }

            await _itemRepository.UpdateItemAsync(item);
            return NoContent();
        }
        [HttpDelete,Route("DeleteItem/{id}")]
        public async Task<IActionResult> DeleteItem(Guid id)
        {
            await _itemRepository.DeleteItemAsync(id);
            return NoContent();
        }
    }
}
