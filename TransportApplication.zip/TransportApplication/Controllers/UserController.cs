﻿using Microsoft.AspNetCore.Mvc;
using TransportApplication.Entity;
using TransportApplication.Repository;

namespace TransportApplication.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : Controller
    {
        private readonly IUserRepository _userRepository;
        public UserController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        [HttpGet, Route("GetAllUsers")]
        public IActionResult GetAllUsers()
        {
            var users = _userRepository.GetAllUsers();
            return Ok(users);
        }
        [HttpPost, Route("Registraion")]
        public IActionResult Add([FromBody] User user)
        {
            if (ModelState.IsValid)
            {
                _userRepository.Register(user);
                return StatusCode(200, user);
            }
            else
            {
                return BadRequest("Enter Valid Details");
            }
        }
        [HttpPost, Route("Validate")]
        public IActionResult ValidUser([FromBody]Login login)
        {

            if (ModelState.IsValid)
            {
               var user = _userRepository.ValidUser(login.Email, login.Password);
                if (user != null)
                {
                    var responuser = new User()
                    {
                        UserId = user.UserId,
                        Role = user.Role,
                        Name = user.Name,
                        Mobile = user.Mobile,

                    };
                }

                return Ok(user);


            }
            else return BadRequest("Enter Valid details");
        }
        [HttpDelete, Route("Delete User")]
        public IActionResult Delete([FromQuery] string id)
        {
            _userRepository.Delete(id);
            return Ok(id);

        }
        [HttpPut, Route("Update User")]
        public IActionResult Update(User user)
        {
            _userRepository.Update(user);
            return StatusCode(200, user);


        }
    }
}
