﻿using Microsoft.AspNetCore.Mvc;
using TransportApplication.Entity;
using TransportApplication.Repository;

namespace TransportApplication.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TransportItemController : Controller
    {
        private readonly ITransportItemRepository _transportItemRepository;

        public TransportItemController(ITransportItemRepository transportItemRepository)
        {
            _transportItemRepository = transportItemRepository;
        }

        [HttpGet,Route("{userId}")] 
        public  async Task<ActionResult<IEnumerable<TransportItem>>> GetTransportItems(Guid userId)
        {
            var transportItems = await _transportItemRepository.GetAllTransportItemsAsync(userId);
            return Ok(transportItems);
        }
        [HttpGet,Route("DetailsItem/{id}")]
        public async Task<ActionResult<TransportItem>> GetTransportItem(Guid id)
        {
            var transportItem = await _transportItemRepository.GetTransportItemByIdAsync(id);
            if (transportItem == null)
            {
                return NotFound();
            }
            return Ok(transportItem);

        }
        [HttpPost,Route("AddTransportItem/{Item}")]
        public async Task<ActionResult> AddTransportItem([FromBody] TransportItem transportItem)
        {
            transportItem.TransportItemId = Guid.NewGuid();
            transportItem.TransportDate = DateTime.UtcNow;
            await _transportItemRepository.AddTransportItemAsync(transportItem);
            return CreatedAtAction(nameof(GetTransportItem), new { id = transportItem.TransportItemId }, transportItem);
        }
        [HttpPut,Route("UpdateItem/{id}")]

        public async Task<IActionResult> UpdateTransportItem(Guid id, [FromBody] TransportItem transportItem)
        {
            if (id != transportItem.TransportItemId)
            {
                return BadRequest();
            }

            await _transportItemRepository.UpdateTransportItemAsync(transportItem);
            return NoContent();
        }
        [HttpDelete,Route("DeleteItem/{id}")]
        public async Task<IActionResult> DeleteTransportItem(Guid id)
        {
            await _transportItemRepository.DeleteTransportItemAsync(id);
            return NoContent();
        }
    }
}
