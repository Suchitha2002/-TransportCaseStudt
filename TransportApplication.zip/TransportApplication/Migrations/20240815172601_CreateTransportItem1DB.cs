﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TransportApplication.Migrations
{
    /// <inheritdoc />
    public partial class CreateTransportItem1DB : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TransportItems_Items_ItemId",
                table: "TransportItems");

            migrationBuilder.DropIndex(
                name: "IX_TransportItems_ItemId",
                table: "TransportItems");

            migrationBuilder.AddColumn<Guid>(
                name: "transportItemItemId",
                table: "TransportItems",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.CreateIndex(
                name: "IX_TransportItems_transportItemItemId",
                table: "TransportItems",
                column: "transportItemItemId");

            migrationBuilder.AddForeignKey(
                name: "FK_TransportItems_Items_transportItemItemId",
                table: "TransportItems",
                column: "transportItemItemId",
                principalTable: "Items",
                principalColumn: "ItemId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TransportItems_Items_transportItemItemId",
                table: "TransportItems");

            migrationBuilder.DropIndex(
                name: "IX_TransportItems_transportItemItemId",
                table: "TransportItems");

            migrationBuilder.DropColumn(
                name: "transportItemItemId",
                table: "TransportItems");

            migrationBuilder.CreateIndex(
                name: "IX_TransportItems_ItemId",
                table: "TransportItems",
                column: "ItemId");

            migrationBuilder.AddForeignKey(
                name: "FK_TransportItems_Items_ItemId",
                table: "TransportItems",
                column: "ItemId",
                principalTable: "Items",
                principalColumn: "ItemId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
