﻿using TransportApplication.Entity;

namespace TransportApplication.Repository
{
    public interface ITransportItemRepository
    {
        Task<IEnumerable<TransportItem>> GetAllTransportItemsAsync(Guid userId);
        Task<TransportItem> GetTransportItemByIdAsync(Guid transportItemId);
        Task AddTransportItemAsync(TransportItem transportItem);
        Task UpdateTransportItemAsync(TransportItem transportItem);
        Task DeleteTransportItemAsync(Guid transportItemId);
    }
}
