﻿using TransportApplication.Entity;

namespace TransportApplication.Repository
{
    public interface IUserRepository
    {
        void Register(User user);

        User ValidUser(string email, string password);
        List<User> GetAllUsers();

        void Delete(string id);

        void Update(User user); 
    }
}
