﻿using Microsoft.EntityFrameworkCore;
using TransportApplication.Entity;

namespace TransportApplication.Repository
{
    public class TransportItemRepository : ITransportItemRepository

    {
        private readonly AppDbContext _context;

        public TransportItemRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task AddTransportItemAsync(TransportItem transportItem)
        {
            await _context.TransportItems.AddAsync(transportItem);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteTransportItemAsync(Guid transportItemId)
        {
            var transportItem = await _context.TransportItems.FindAsync(transportItemId);
            if (transportItem != null)
            {
                _context.TransportItems.Remove(transportItem);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<IEnumerable<TransportItem>> GetAllTransportItemsAsync(Guid userId)
        {
            return await _context.TransportItems
                                 .Where(t => t.UserId == userId)
                                 .Include(t => t.transportItem) 
                                 .ToListAsync();
        }
        public async Task<TransportItem> GetTransportItemByIdAsync(Guid transportItemId)
        {
            return await _context.TransportItems
                                 .Include(t => t.ItemId)
                                 .FirstOrDefaultAsync(t=> t.ItemId == transportItemId);  
        }
        public async Task UpdateTransportItemAsync(TransportItem transportItem)
        {
            _context.TransportItems.Update(transportItem);
            await _context.SaveChangesAsync(); 
        }
    }

}


