﻿using Microsoft.EntityFrameworkCore;
using TransportApplication.Entity;

namespace TransportApplication.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly AppDbContext _context;

        public UserRepository(AppDbContext context)
        {
            _context = context;
        }

        public void Delete(string id)
        {
            var user = _context.Users.Find(id);
            if (user != null)
            {
                _context.Users.Remove(user);
                _context.SaveChanges();
            }
        }

        public List<User> GetAllUsers()
        {
            return _context.Users.ToList();


        }

        public void Register(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
        }

        public void Update(User user)
        {
            _context.Users.Update(user);
            _context.SaveChanges();
        }

        public User ValidUser(string email, string password)
        {
            try
            {
                var user = _context.Users.FirstOrDefault(u => u.Email == email && u.Password == password);
                if (user != null)
                {
                    return user;
                }
                else
                {
                    Console.WriteLine("User validation failed.");
                    return null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("an Error Ocucured" + ex.Message);
                return null;

            }



        }
    }
}
