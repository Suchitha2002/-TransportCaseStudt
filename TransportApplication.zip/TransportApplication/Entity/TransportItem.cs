﻿namespace TransportApplication.Entity
{
    public class TransportItem
    {
        public Guid TransportItemId { get; set; }
        public Guid UserId { get; set; }
        public Guid ItemId { get; set; }

        public Item transportItem { get; set; }  
        public DateTime TransportDate { get; set; }
        public string Destination { get; set; }
    }
}
